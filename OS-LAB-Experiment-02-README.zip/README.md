# OS Lab Experiments

## Experiment 02

**Name:** YUVARAJ K  
**Register Number:** 2104251041122  
**Class:** CSE – A  
**Experiment Number:** 02  

### Program

The following Bash shell script finds the greatest of three numbers.

```bash
#!/bin/bash

echo "ENTER THREE NUMBERS"
read a b c

if [ $a -gt $b ] && [ $a -gt $c ]
then
    echo "$a is greater"
elif [ $b -gt $c ]
then
    echo "$b is greater"
else
    echo "$c is greater"
fi
```

### Program in Kali Linux

![Bash program](images/program.png)

### Output

The program was executed with the input `5 9 4`, and the output was:

```text
ENTER THREE NUMBERS
5 9 4
9 is greater
```

![Program output](images/output.png)

---
